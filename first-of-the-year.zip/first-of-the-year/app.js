const PACKS = RAW_PACKS.map(p => ({ map: p.map, hold: new Set(p.hold), linked: p.linked }));

const HAS_SOUNDS = PACKS.map(p => p.map.some(Boolean));

const CODES = [
  'Digit1','Digit2','Digit3','Digit4','Digit5','Digit6','Digit7','Digit8','Digit9','Digit0','Minus','Equal',
  'KeyQ','KeyW','KeyE','KeyR','KeyT','KeyY','KeyU','KeyI','KeyO','KeyP','BracketLeft','BracketRight',
  'KeyA','KeyS','KeyD','KeyF','KeyG','KeyH','KeyJ','KeyK','KeyL','Semicolon','Quote','Enter',
  'KeyZ','KeyX','KeyC','KeyV','KeyB','KeyN','KeyM','Comma','Period','Slash','ShiftLeft', null
];
const LABELS = [
  '1','2','3','4','5','6','7','8','9','0','-','=',
  'Q','W','E','R','T','Y','U','I','O','P','[',']',
  'A','S','D','F','G','H','J','K','L',';',"'",'\u21B5',
  'Z','X','C','V','B','N','M',',','.','/','\u21E7','tap'
];
const CODE_TO_PAD = {};
CODES.forEach((c, i) => { if (c) CODE_TO_PAD[c] = i; });
CODE_TO_PAD.ShiftRight = 46;
const ARROW_TO_PACK = { ArrowLeft: 0, ArrowUp: 1, ArrowDown: 2, ArrowRight: 3 };

const grid = document.getElementById('grid');
const statusEl = document.getElementById('status');
const dpadBtns = [...document.querySelectorAll('#dpad button')];
const pads = [];
let pack = 0;

const AC = window.AudioContext || window.webkitAudioContext;
const ctx = new AC({ latencyHint: 'interactive' });
const master = ctx.createGain();
master.connect(ctx.destination);
const buffers = {};
const voices = new Map();
const heldPack = {};

for (let i = 0; i < 48; i++) {
  const el = document.createElement('div');
  el.className = 'pad';
  el.textContent = LABELS[i];
  el.setAttribute('role', 'button');
  el.setAttribute('aria-label', 'Pad ' + LABELS[i]);
  el.addEventListener('pointerdown', e => {
    e.preventDefault();
    try { el.setPointerCapture(e.pointerId); } catch (_) {}
    press(i);
  });
  const up = () => release(i);
  el.addEventListener('pointerup', up);
  el.addEventListener('pointercancel', up);
  el.addEventListener('contextmenu', e => e.preventDefault());
  grid.appendChild(el);
  pads.push(el);
}

function refreshPad(i) {
  const el = pads[i];
  const p = PACKS[pack];
  const has = !!p.map[i];
  el.classList.toggle('empty', !has);
  el.classList.toggle('hold', has && p.hold.has(i));
  el.classList.toggle('live', voices.has(pack + ':' + i));
}
function refreshAll() { for (let i = 0; i < 48; i++) refreshPad(i); }

function stopVoice(key, fade) {
  const v = voices.get(key);
  if (!v) return;
  voices.delete(key);
  const t = ctx.currentTime;
  v.g.gain.cancelScheduledValues(t);
  v.g.gain.setValueAtTime(v.g.gain.value, t);
  v.g.gain.linearRampToValueAtTime(0, t + fade);
  try { v.src.stop(t + fade + 0.005); } catch (_) {}
  if (v.p === pack) refreshPad(v.i);
}

function startVoice(p, i) {
  const buf = buffers[PACKS[p].map[i]];
  if (!buf) return;
  const key = p + ':' + i;
  stopVoice(key, 0.012);
  const src = ctx.createBufferSource();
  src.buffer = buf;
  const g = ctx.createGain();
  src.connect(g);
  g.connect(master);
  const v = { src, g, p, i };
  voices.set(key, v);
  src.onended = () => {
    if (voices.get(key) === v) { voices.delete(key); if (p === pack) refreshPad(i); }
  };
  src.start();
  for (const group of PACKS[p].linked) {
    if (group.includes(i)) for (const j of group) if (j !== i) stopVoice(p + ':' + j, 0.012);
  }
  if (p === pack) refreshPad(i);
}

function press(i) {
  if (heldPack[i] !== undefined || !PACKS[pack].map[i]) return;
  if (ctx.state !== 'running') ctx.resume();
  heldPack[i] = pack;
  pads[i].classList.add('held');
  startVoice(pack, i);
}

function release(i) {
  const p = heldPack[i];
  if (p === undefined) return;
  delete heldPack[i];
  pads[i].classList.remove('held');
  if (PACKS[p].hold.has(i)) stopVoice(p + ':' + i, 0.03);
}

function releaseAllHeld() { Object.keys(heldPack).forEach(i => release(+i)); }

function switchPack(n) {
  if (n === pack || !HAS_SOUNDS[n]) return;
  releaseAllHeld();
  pack = n;
  dpadBtns.forEach(b => b.setAttribute('aria-pressed', String(+b.dataset.pack === pack)));
  statusEl.textContent = 'Sound pack ' + (pack + 1);
  refreshAll();
}

function stopAll() {
  releaseAllHeld();
  [...voices.keys()].forEach(k => stopVoice(k, 0.05));
  statusEl.textContent = 'Stopped';
}

document.addEventListener('keydown', e => {
  if (e.ctrlKey || e.metaKey || e.altKey) return;
  if (e.code in ARROW_TO_PACK) { e.preventDefault(); switchPack(ARROW_TO_PACK[e.code]); return; }
  if (e.code === 'Escape') { stopAll(); return; }
  const i = CODE_TO_PAD[e.code];
  if (i === undefined) return;
  e.preventDefault();
  if (!e.repeat) press(i);
});
document.addEventListener('keyup', e => {
  const i = CODE_TO_PAD[e.code];
  if (i !== undefined) { e.preventDefault(); release(i); }
});
window.addEventListener('blur', releaseAllHeld);

dpadBtns.forEach(b => b.addEventListener('click', () => { switchPack(+b.dataset.pack); b.blur(); }));
document.getElementById('stopAll').addEventListener('click', e => { stopAll(); e.currentTarget.blur(); });

async function decodeAll() {
  const ids = Object.keys(SAMPLES);
  const meter = document.getElementById('meter');
  const msg = document.getElementById('loadMsg');
  let done = 0;
  await Promise.all(ids.map(async id => {
    try {
      const bin = atob(SAMPLES[id]);
      const u8 = new Uint8Array(bin.length);
      for (let k = 0; k < bin.length; k++) u8[k] = bin.charCodeAt(k);
      buffers[id] = await ctx.decodeAudioData(u8.buffer);
    } catch (err) {
      console.error('Could not decode sample', id, err);
    }
    delete SAMPLES[id];
    done++;
    meter.style.width = Math.round((done / ids.length) * 100) + '%';
    msg.textContent = 'Loading samples ' + done + ' of ' + ids.length;
  }));
}

dpadBtns.forEach(b => { b.hidden = !HAS_SOUNDS[+b.dataset.pack]; b.setAttribute('aria-pressed', String(+b.dataset.pack === pack)); });
refreshAll();
decodeAll().then(() => {
  document.getElementById('loading').hidden = true;
  statusEl.textContent = 'Ready. Press any key on the grid.';
});
